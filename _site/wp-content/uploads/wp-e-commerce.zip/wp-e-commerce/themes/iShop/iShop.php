<?php
// if(get_option('wpsc_selected_theme') == 'iShop') {
// 	function wpsc_theme_html($product) {
// 		$siteurl = get_option('siteurl');
// 		$wpsc_theme['html'] ="<input type='image' src='".WPSC_URL."/themes/iShop/images/buy_button.gif' id='product_".$product['id']."_submit_button' class='wpsc_buy_button' name='Buy' value='".__('Add To Cart', 'wpsc')."'  />";
// 		return $wpsc_theme;
// 	}
// }
?>