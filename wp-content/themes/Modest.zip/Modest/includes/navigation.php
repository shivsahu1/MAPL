<div class="pagination">
	<div class="alignleft"><?php next_posts_link(__('&laquo; Older Entries','Modest')) ?></div>
	<div class="alignright"><?php previous_posts_link(__('Next Entries &raquo;', 'Modest')) ?></div>
</div>